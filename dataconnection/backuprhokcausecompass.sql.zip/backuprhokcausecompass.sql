-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.npbendre.com
-- Generation Time: Dec 01, 2012 at 08:09 PM
-- Server version: 5.1.39
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rhokcausecompass`
--

-- --------------------------------------------------------

--
-- Table structure for table `causecharity`
--

CREATE TABLE IF NOT EXISTS `causecharity` (
  `cause_id` int(20) NOT NULL,
  `charity_id` int(20) NOT NULL,
  `charity_type` int(5) NOT NULL,
  UNIQUE KEY `cause_id` (`cause_id`,`charity_id`,`charity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `causecharity`
--

INSERT INTO `causecharity` (`cause_id`, `charity_id`, `charity_type`) VALUES
(1, 1, 1),
(1, 2, 1),
(1, 9, 1),
(2, 2, 1),
(2, 3, 1),
(2, 3, 2),
(3, 2, 1),
(3, 6, 2),
(3, 8, 1),
(3, 12, 1),
(3, 12, 2),
(3, 19, 1),
(3, 19, 3),
(4, 6, 1),
(4, 6, 2),
(7, 6, 1),
(7, 6, 2),
(8, 2, 1),
(10, 9, 1),
(10, 9, 2),
(10, 18, 1),
(10, 18, 3),
(11, 15, 1),
(11, 15, 3),
(12, 15, 1),
(12, 15, 3),
(12, 17, 1),
(12, 17, 3),
(20, 20, 3);

-- --------------------------------------------------------

--
-- Table structure for table `causetable`
--

CREATE TABLE IF NOT EXISTS `causetable` (
  `cause_id` int(20) NOT NULL AUTO_INCREMENT,
  `cause_name` varchar(30) NOT NULL,
  PRIMARY KEY (`cause_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `causetable`
--

INSERT INTO `causetable` (`cause_id`, `cause_name`) VALUES
(1, 'Cancer'),
(2, 'Hurricane Sandy'),
(3, 'Children'),
(4, 'Orphanage'),
(5, 'Earthquake'),
(6, 'Education'),
(7, 'Hunger & Proverty'),
(8, 'Flood Relief'),
(9, 'Veterans'),
(10, 'Old Age Homes'),
(11, 'Animal Relief'),
(12, 'Environmental Relief'),
(13, 'International Development NGOs'),
(14, 'Patient & Family Support'),
(15, 'Performing Arts'),
(16, 'Libraries & Historical Societi'),
(17, 'Public Broadcasting and Media'),
(18, 'Peace & Human Rights'),
(19, 'Disaster Relief'),
(20, 'Daily Life Volunteering');

-- --------------------------------------------------------

--
-- Table structure for table `charitytable`
--

CREATE TABLE IF NOT EXISTS `charitytable` (
  `charity_id` int(20) NOT NULL AUTO_INCREMENT,
  `charity_name` varchar(30) NOT NULL,
  `street` varchar(20) NOT NULL,
  `zipcode` int(6) NOT NULL,
  `cityname` varchar(20) NOT NULL,
  `State` varchar(25) NOT NULL,
  `Country` varchar(30) NOT NULL,
  `city_lat` float NOT NULL,
  `city_long` float NOT NULL,
  `phonenumber` varchar(15) NOT NULL,
  `website_link` varchar(100) NOT NULL,
  `emailaddress` varchar(20) NOT NULL,
  `additional_info` varchar(200) NOT NULL,
  PRIMARY KEY (`charity_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `charitytable`
--

INSERT INTO `charitytable` (`charity_id`, `charity_name`, `street`, `zipcode`, `cityname`, `State`, `Country`, `city_lat`, `city_long`, `phonenumber`, `website_link`, `emailaddress`, `additional_info`) VALUES
(1, 'American Institute for Cancer ', '1759 R Street, NW', 20009, 'Washington DC', 'DC', 'USA', 38.89, -77.03, '(800) 843-8114', 'http://www.aicr.org/', 'aicrweb@aicr.org', 'http://www.aicr.org/how-you-can-help/'),
(2, 'Network for Good', '1140 Connecticut Ave', 20036, 'Washington DC', 'DC', 'USA', 38.9, -77.04, '888.284.7978', 'http://www1.networkforgood.org/', 'community@networkfor', 'http://www.thenetworkforgood.org/t5/About-our-Community/Getting-Started-in-the-Community/td-p/13'),
(3, 'American Red Cross', '1955 Monroe Drive', 30301, 'Atlanta', 'GA', 'USA', 33.6936, -84.2022, '', 'http://www.redcross.org/', '', 'http://www.redcross.org/support/donating-fundraising/donations'),
(4, 'Atlanta Community Food Bank', '732 Joseph E. Lowery', 30318, 'Atlanta', 'GA', 'USA', 33.775, -84.4, '404.892.FEED', 'http://www.acfb.org', 'feedback@acfb.org', ''),
(5, 'Animal Defense League', '11300 Nacogdoches Rd', 78217, 'San Antonio', 'TX', 'USA', 29.5418, -98.418, '(210) 655-1481', 'www.animaldefenseleague.org', '', ''),
(6, 'Henry Street Settlement', '265 Henry Street', 10002, 'New York', 'NY', 'USA', 40.7141, -73.98, '212.766.9200', 'http://www.henrystreet.org/', 'info@henrystreet.org', ''),
(7, 'Learning Leaders, Inc.', '80 Maiden Lane, 11th', 10038, 'New York', 'NY', 'USA', 40.7096, -74, '(212) 213-3370', 'http://www.learningleaders.org/', '', ''),
(8, 'Ronald McDonald House Charitie', 'One Kroc Drive, Oak ', 60523, 'Oak Brook', 'IL', 'USA', 41.8352, -87.94, '630.623.7048', 'http://www.rmhc.org', 'info@rmhc.org', ''),
(9, 'United Funding Inc', '3600 Mansell Road ', 30022, 'Alpharetta', 'GA', 'USA', 34.0393, -84.2972, '(678) 397-0800', '', '', ''),
(10, 'The Atlanta Humane Society', '981 Howell Mill Road', 30318, 'Atlanta', 'GA', 'USA', 33.7815, -84.411, '404.875.5331', 'http://atlantahumane.org/', '', ''),
(11, 'The Atlanta Humane Society', '1565 Mansell Road', 30009, 'Alpharetta', 'GA', 'USA', 34.04, -84.319, '404.875.5331', 'http://atlantahumane.org/', '', ''),
(12, 'Cedartown Church Of Christ', '326 East Ave', 30125, 'Cedartown', 'GA', 'USA', 34.0143, -85.25, '(770) 748-6676', '', '', ''),
(13, 'Gwinnett Humane Society', '3724 Lawrenceville H', 30044, 'Lawrenceville', 'GA', 'USA', 33.908, -84.1, '(770) 925-1433', '', '', ''),
(14, 'Cherokee County Humane Society', '5902 Bells Ferry Rd', 30102, 'Acworth', 'GA', 'USA', 34.096, -84.5823, '(770) 592-8350', '', '', ''),
(15, 'American Hiking Society', '1422 Fenwick Lane', 20910, 'Silver Spring', 'MD', 'USA', 38.996, -77.03, '(800) 972-8608', 'http://www.americanhiking.org/', 'info@AmericanHiking.', ''),
(16, 'American Horticultural Society', '7931 East Boulevard ', 22308, 'Alexandria', 'VA', 'USA', 38.742, -77.04, '(800) 777-7931', 'http://www.ahs.org/', 'webmaster@ahs.org', ''),
(17, 'The Aspen Center for Environme', '100 Puppy Smith St.', 81611, 'Aspen', 'CO', 'USA', 39.1964, -106.82, '970.925.5756', 'http://www.aspennature.org/', 'aces@aspennature.org', ''),
(18, 'Light of Hearts Villa', '283 Union Street', 44146, 'Bedford', 'OH', 'USA', 41.3836, -81.523, '(440)232-1991', 'http://www.lightofheartsvilla.org/', '', ''),
(19, 'The Seton Family Center', '3316 Werk Road', 45211, 'Cincinnati', 'OH', 'USA', 39.141, -84.615, '513-471-9169', 'http://setonfamilycenter.org', '', 'Volunteering'),
(20, 'Voolla', 'Austin', 73301, 'Austin', 'TX', 'USA', 30.222, -97.747, '', 'http://voolla.org', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `charitytype`
--

CREATE TABLE IF NOT EXISTS `charitytype` (
  `charity_type_id` int(5) NOT NULL AUTO_INCREMENT,
  `chaity_type_name` varchar(50) NOT NULL,
  PRIMARY KEY (`charity_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `charitytype`
--

INSERT INTO `charitytype` (`charity_type_id`, `chaity_type_name`) VALUES
(1, 'Monetary'),
(2, 'Kind'),
(3, 'Volunteer Service');

-- --------------------------------------------------------

--
-- Table structure for table `TABLE 5`
--

CREATE TABLE IF NOT EXISTS `TABLE 5` (
  `COL 1` int(2) DEFAULT NULL,
  `COL 2` varchar(45) DEFAULT NULL,
  `COL 3` varchar(37) DEFAULT NULL,
  `COL 4` int(5) DEFAULT NULL,
  `COL 5` varchar(13) DEFAULT NULL,
  `COL 6` varchar(2) DEFAULT NULL,
  `COL 7` varchar(6) DEFAULT NULL,
  `COL 8` varchar(7) DEFAULT NULL,
  `COL 9` varchar(14) DEFAULT NULL,
  `COL 10` varchar(31) DEFAULT NULL,
  `COL 11` varchar(28) DEFAULT NULL,
  `COL 12` varchar(96) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLE 5`
--

INSERT INTO `TABLE 5` (`COL 1`, `COL 2`, `COL 3`, `COL 4`, `COL 5`, `COL 6`, `COL 7`, `COL 8`, `COL 9`, `COL 10`, `COL 11`, `COL 12`) VALUES
(1, 'American Institute for Cancer Research', '1759 R Street, NW', 20009, 'Washington DC', 'DC', '38.89', '-77.03', '(800) 843-8114', 'http://www.aicr.org/', 'aicrweb@aicr.org', 'http://www.aicr.org/how-you-can-help/'),
(2, 'Network for Good', '1140 Connecticut Avenue NW, Suite 700', 20036, 'Washington DC', 'DC', '38.9', '-77.04', '888.284.7978', 'http://www1.networkforgood.org/', 'community@networkforgood.org', 'http://www.thenetworkforgood.org/t5/About-our-Community/Getting-Started-in-the-Community/td-p/13'),
(3, 'American Red Cross', '1955 Monroe Drive', 30301, 'Atlanta', 'GA', '33.693', '-84.202', '', 'http://www.redcross.org/', '', 'http://www.redcross.org/support/donating-fundraising/donations'),
(4, 'Atlanta Community Food Bank', '732 Joseph E. Lowery Blvd., NW', 30318, 'Atlanta', 'GA', '33.775', '-84.4', '404.892.FEED', 'http://www.acfb.org', 'feedback@acfb.org', ''),
(5, 'Animal Defense League', '11300 Nacogdoches Rd', 78217, 'San Antonio', 'TX', '29.541', '-98.418', '(210) 655-1481', 'www.animaldefenseleague.org', '', ''),
(6, 'Henry Street Settlement', '265 Henry Street', 10002, 'New York', 'NY', '40.714', '-73.98', '212.766.9200', 'http://www.henrystreet.org/', 'info@henrystreet.org', ''),
(7, 'Learning Leaders, Inc.', '80 Maiden Lane, 11th Floor', 10038, 'New York', 'NY', '40.709', '-74', '(212) 213-3370', 'http://www.learningleaders.org/', '', ''),
(8, 'Ronald McDonald House Charities', 'One Kroc Drive, Oak Brook,', 60523, 'Oak Brook', 'IL', '41.835', '-87.94', '630.623.7048', 'http://www.rmhc.org', 'info@rmhc.org', ''),
(9, 'United Funding Inc', '3600 Mansell Road ', 30022, 'Alpharetta', 'GA', '34.039', '-84.297', '(678) 397-0800', '', '', ''),
(10, 'The Atlanta Humane Society', '981 Howell Mill Road NW', 30318, 'Atlanta', 'GA', '33.781', '-84.411', '404.875.5331', 'http://atlantahumane.org/', '', ''),
(11, 'The Atlanta Humane Society', '1565 Mansell Road', 30009, 'Alpharetta', 'GA', '34.04', '-84.319', '404.875.5331', 'http://atlantahumane.org/', '', ''),
(12, 'Cedartown Church Of Christ', '326 East Ave', 30125, 'Cedartown', 'GA', '', '', '(770) 748-6676', '', '', ''),
(13, 'Gwinnett Humane Society', '3724 Lawrenceville Hwy', 30044, 'Lawrenceville', 'GA', '', '', '(770) 925-1433', '', '', ''),
(14, 'Cherokee County Humane Society Cents of Style', '5902 Bells Ferry Rd', 30102, 'Acworth', 'GA', '', '', '(770) 592-8350', '', '', '');
